package ProjectManagement;

public class Job implements Comparable<Job> {

  
    public String name;
    public Project project;
    public User user;
    public int jobtime;
    public int finaltime=0;
    public int status=0;
    public int priority1=0;
    
    public Job(String n, Project p, User u , int j)
    {
        name=n;
        project=p;
        user=u;
        jobtime=j;
        
    }
    @Override
    public int compareTo(Job job) 
    {
        if(project.priority!=job.project.priority)
        return project.priority-job.project.priority;
        else
        return job.priority1-priority1;
        
    }
}